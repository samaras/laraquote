 
<?php $__env->startSection('content'); ?>
	<?php $__env->startSection('pageheader'); ?>
    	Edit Currency
    <?php $__env->stopSection(); ?>
 
    <?php echo Form::model($currency, ['method' => 'PATCH', 'route' => ['currencies.update']]); ?>

        <?php echo $__env->make('currencies/partials/_form', ['submit_text' => 'Edit Currency'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>