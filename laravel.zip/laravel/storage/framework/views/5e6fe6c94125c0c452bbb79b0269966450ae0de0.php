<?php $__env->startSection('content'); ?>
<p class="login-box-msg">Sign in to start your session</p>
<div class="container-fluid">
	<div class="row">
		<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<strong>Whoops!</strong> There were some problems with your input.<br><br>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>

		<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

			<div class="form-group has-feedback">
				<div class="col-md-12">
					<input type="email" class="form-control" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
				</div>
			</div>

			<div class="form-group has-feedback">
				<div class="col-md-12">
					<input type="password" class="form-control" placeholder="Password" name="password">
				</div>
			</div>

			<div class="row">
				<div class="col-xs-8" style="padding-right: 35px;">
					<div class="checkbox">
                          <label>
                            <input type="checkbox" name="remember"> Remember me
                          </label>
					</div>
				</div>
			</div>
			<br />
			<div class="row">
				<div class="col-xs-4">
					<button type="submit" class="btn btn-primary btn-block btn-flat">Login</button>
				</div>
			</div>
		</form>
	</div>
</div>
<br />
<div class="text-center">
	<a href="<?php echo e(url('/password/email')); ?>">I forgot my password</a><br>
	<a href="<?php echo e(url('/register')); ?>" class="text-center">Register a new membership</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>