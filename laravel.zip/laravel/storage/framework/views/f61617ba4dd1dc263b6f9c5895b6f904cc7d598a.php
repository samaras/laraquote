 
<?php $__env->startSection('content'); ?>
<section>
	<div class="col-xs-12">
		<div class="box box-primary">
		<div class="box-header with-border">
			<div class="col-md-6" style="padding-top: 5px"><?php echo link_to_route('products.create', 'Create Product', array(), ['class' => 'btn btn-default']); ?></div>
			<div class="col-md-6"><?php echo $__env->make('toolboxsearch', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
		</div>
	 
		<p>&nbsp;</p>
		<?php if(!$products->count() ): ?>
			No products found
		<?php else: ?>
		<div class="box-body">
			<div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
				<div class="row">
					<div class="col-sm-12">
						<table class="table table-hover dataTable" id="example1" role="grid" aria-describedby="example1_info">
							<thead>
								<tr role="row">
									<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 180px;">Name</th>
									<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Category</th>
									<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Description</th>
									<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Stock</th>
									<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Created At</th>
									<th style="width: 150px"></th>
								</tr>
							</thead>
							<tbody>
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<tr>
									<?php echo Form::open(array('class' => 'form-inline', 'method' => 'DELETE', 'route' => array('products.destroy', $product->id))); ?>

										<td><a href="<?php echo e(route('products.show', $product->id)); ?>"><?php echo e($product->name); ?></a></td>
										<td><?php echo e($product->category->category); ?></td>
										<td><?php echo e($product->description); ?></td>
										<td><?php echo e($product->stock); ?></td>
										<td></td>
										<td style="text-align: center">
											<?php echo link_to_route('products.edit', 'Edit', $product->id, array('class' => 'btn btn-info btn-sm btn-flat glyphicon glyphicon-edit')); ?>

											<?php echo Form::submit('Delete', array('class' => 'btn btn-danger btn-sm btn-flat glyphicon glyphicon-trash')); ?>

										</td>
									<?php echo Form::close(); ?>

								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
				<?php endif; ?>
			</div>
		</div>
</section>

<div class="pull-right">
	<?php echo $products->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>