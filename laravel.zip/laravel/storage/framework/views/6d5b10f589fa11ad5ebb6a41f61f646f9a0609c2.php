 
<?php $__env->startSection('content'); ?>
    <p>
        <?php echo link_to_route('categories.index', 'Back to category'); ?> |
        <?php echo link_to_route('categories.create', 'Create Category'); ?>

    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>