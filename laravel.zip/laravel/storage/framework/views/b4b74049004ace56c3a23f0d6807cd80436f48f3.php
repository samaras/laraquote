 
<?php $__env->startSection('content'); ?>
 	<?php $__env->startSection('pageheader'); ?>
 		Create Category
 	<?php $__env->stopSection(); ?>
 
    <?php echo Form::model(new App\Models\Category, ['route' => ['categories.store']], array('class'=>'form-horizontal')); ?>

        <?php echo $__env->make('categories/partials/_form', ['submit_text' => 'Create Category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>