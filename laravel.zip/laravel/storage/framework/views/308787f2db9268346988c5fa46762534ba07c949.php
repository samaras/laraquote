<h1>
	<?php echo $page_title; ?>

	<small><?php echo $__env->yieldContent('pagedescription'); ?>Control Panel</small>
</h1>
