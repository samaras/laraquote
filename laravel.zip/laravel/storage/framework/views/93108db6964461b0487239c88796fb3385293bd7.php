<?php $__env->startSection('pagedescription'); ?>
	Companies and Customers
<?php $__env->stopSection(); ?> 
 
<?php $__env->startSection('content'); ?>
	<div class="col-xs-12">
		<div class="box box-primary">
			<div class="box-header with-border">
				<div class="col-md-6" style="padding-top: 5px"><?php echo link_to_route('clients.create', 'Create Client', array(), ['class' => 'btn btn-default']); ?></div>
				<div class="col-md-6"><?php echo $__env->make('toolboxsearch', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
			</div>
			

			<p>&nbsp;</p>
				<div class="box-body">
					<div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
						<div class="row">
							<div class="col-sm-12">
								<table class="table table-hover" id="example1" role="grid" aria-describedby="example1_info">
									<thead>
										<tr role="row">
											<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 50px;">#</th>
											<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 180px;">Client</th>
											<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Address</th>
											<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Province</th>
											<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Postal Code</th>
											<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Phone Number</th>
											<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Cell Number</th>
											<th style="width: 150px"></th>
										</tr>
									</thead>
									<tbody>
									<?php if(!$clients->count()): ?>
									<tr>
										<td colspan="4" class="text-center">
											No clients found.
										</td>
									</tr>
									<?php else: ?>
										<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
											<tr role="row" class="odd">
												<?php echo Form::open(array('class' => 'form-inline', 'method' => 'DELETE', 'route' => array('clients.destroy', $client->id))); ?>

													<td> # </td>
													<td><a href="<?php echo e(route('clients.show', $client->id)); ?>"><?php echo e($client->contact_person); ?> (<?php echo e($client->company); ?>)</a></td>
													<td style="overflow: hidden;"><?php echo e($client->address); ?>, <?php echo e($client->address_line1); ?>, <?php echo e($client->address_line2); ?>, <?php echo e($client->address_line3); ?>,</td>
													<td><?php echo e($client->province); ?></td>
													<td><?php echo e($client->postal_code); ?></td>
													<td><?php echo e($client->phone_number); ?></td>
													<td><?php echo e($client->cell_number); ?></td>
													<td style="text-align: center">
														<?php echo link_to_route('clients.edit', 'Edit', $client->id,  array('class' => 'btn btn-info btn-sm btn-flat glyphicon glyphicon-edit')); ?>

														<?php echo Form::submit('Delete', array('class' => 'btn btn-danger btn-sm btn-flat glyphicon glyphicon-trash')); ?>

													</td>
												<?php echo Form::close(); ?>

											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
									<?php endif; ?>
									</tbody>
								</table>
							</div>
						</div>
				</div> <!-- box-body -->
		</div> <!-- box-primary -->
	</div>
	
	<div class="pull-right">
		<?php echo $clients->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>