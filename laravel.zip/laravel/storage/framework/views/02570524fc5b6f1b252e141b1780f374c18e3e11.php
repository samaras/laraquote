 
<?php $__env->startSection('content'); ?>
<section>
	<div class="col-xs-12">
		<div class="box box-primary">
			<div class="box-header with-border"> 
				<div class="col-md-6" style="padding-top: 5px"><?php echo link_to_route('currencies.create', 'Create Currency', array(), ['class' => 'btn btn-default']); ?></div>
				<div class="col-md-6"><?php echo $__env->make('toolboxsearch', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
			</div>
            
            <p>&nbsp;</p>
		    <?php if( !$currencies->count() ): ?>
		        No currencies found
		    <?php else: ?>
			<div class="box-body">
                <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                    <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-hover dataTable" id="example1" role="grid" aria-describedby="example1_info">
                                <thead>
                                    <tr role="row">
					                    <th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 180px;">Currency</th>
					                    <th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Code</th>
					                    <th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Symbol</th>
					                    <th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Created At</th>
					                    <th style="width: 150px"></th>
				                    </tr>
                				</thead>
			                    <tbody>
						            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						                <tr role="row" class="odd">
					                    <?php echo Form::open(array('class' => 'form-inline', 'method' => 'DELETE', 'route' => array('currencies.destroy', $currency->id))); ?>

					                        <td><a href="<?php echo e(route('currencies.show', $currency->id)); ?>"><?php echo e($currency->currency); ?></a></td>
					                        <td><?php echo e($currency->code); ?></td>
					                        <td><?php echo e($currency->symbol); ?></td>
					                        <td></td>
					                        <td style="text-align: center">
					                            <?php echo link_to_route('currencies.edit', 'Edit', $currency->id, array('class' => 'btn btn-info btn-sm btn-flat glyphicon glyphicon-edit')); ?>

					                            <?php echo Form::submit('Delete', array('class' => 'btn btn-danger btn-sm btn-flat glyphicon glyphicon-trash')); ?>

					                        </td>
					                    <?php echo Form::close(); ?>

		                				</tr>
		            				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	            				</tbody>
			                </table>
			            </div>
			        </div>
				<?php endif; ?>
			</div>
		</div>
    </section> 
 
    <div class="pull-right">
		<?php echo $currencies->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>