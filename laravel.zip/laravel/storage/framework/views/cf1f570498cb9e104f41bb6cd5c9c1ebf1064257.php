<div class="box-body">
    <div class="form-group row">
        <?php echo Form::label('first_name', 'First Name:', array('class'=>'col-md-2 control-label')); ?>

        <div class="col-md-6"><?php echo Form::text('first_name'); ?></div>
    </div>
     
    <div class="form-group row">
        <?php echo Form::label('last_name', 'Last Name:', array('class'=>'col-md-2 control-label')); ?>

        <div class="col-md-6"><?php echo Form::text('last_name'); ?></div>
    </div>

    <div class="form-group row">
        <?php echo Form::label('email', 'Email:', array('class'=>'col-md-2 control-label')); ?>

        <div class="col-md-6"><?php echo Form::text('email'); ?></div>
    </div>

    <div class="form-group row">
        <?php echo Form::label('password', 'Password:', array('class'=>'col-md-2 control-label')); ?>

        <div class="col-md-6"><?php echo Form::password('password'); ?></div>
    </div>
     
    <div class="form-group row">
        <?php echo Form::label('active', 'Active:', array('class'=>'col-md-2 control-label')); ?>

        <div class="col-md-6"><?php echo Form::checkbox('active'); ?></div>
    </div>
     
    <div class="form-group">
        <div class="col-md-2">
            <?php echo Form::submit($submit_text); ?>

        </div>
    </div>
</div>