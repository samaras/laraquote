 
<?php $__env->startSection('content'); ?>
<section>
	<div class="col-xs-12">
		<div class="box box-primary">
			<div class="box-header with-border">
				<div class="col-md-6" style="padding-top: 5px"><?php echo link_to_route('discounts.create', 'Create Discount', array(), ['class' => 'btn btn-default']); ?></div>
				<div class="col-md-6"><?php echo $__env->make('toolboxsearch', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
			</div>
 
            <?php if( !$discounts->count() ): ?>
                No discounts found
            <?php else: ?>
            <div class="box-body">
                <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                    <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-hover dataTable" id="example1" role="grid" aria-describedby="example1_info">
                                <thead>
                                    <tr role="row">
										<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 180px;">#</th>
                	                    <th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 180px;">Discount</th>
                	                    <th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Created At</th>
                	                    <th style="width: 150px"></th>
                                    </tr>                                        
                                </thead>
                                <tbody>
            			            <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            			                <tr role="row" class="odd">
            			                    <?php echo Form::open(array('class' => 'form-inline', 'method' => 'DELETE', 'route' => array('discounts.destroy', $discount->id))); ?>

												<td> # </td>
            			                        <td><a href="<?php echo e(route('discounts.show', $discount->id)); ?>"><?php echo e($discount->discount); ?></a></td>
            			                        <td></td>
            			                        <td style="text-align: center">
            			                            <?php echo link_to_route('discounts.edit', 'Edit', $discount->id, array('class' => 'btn btn-info btn-sm btn-flat glyphicon glyphicon-edit')); ?>

            			                            <?php echo Form::submit('Delete', array('class' => 'btn btn-danger btn-sm btn-flat glyphicon glyphicon-trash')); ?>

            			                        </td>
            			                    <?php echo Form::close(); ?>

            			                </tr>
            			            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
</section>
<div class="pull-right">
	<?php echo $discounts->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>