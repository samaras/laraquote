 
<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('pageheader'); ?>
    	Edit Discount
    <?php $__env->stopSection(); ?>
 
    <?php echo Form::model($discount, ['method' => 'PATCH', 'route' => ['discounts.update']]); ?>

        <?php echo $__env->make('discounts/partials/_form', ['submit_text' => 'Edit Discount'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>