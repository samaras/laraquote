 
<?php $__env->startSection('pagedescription'); ?>
	Quotations
<?php $__env->stopSection(); ?> 
 
<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
	<div class="box box-primary">
		<div class="box-header with-border">
			<div class="col-md-6" style="padding-top: 5px"><?php echo link_to_route('quotes.create', 'Create Quote', array(), ['class' => 'btn btn-default']); ?></div>
			<div class="col-md-6"><?php echo $__env->make('toolboxsearch', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
		</div>
 
		<p>&nbsp;</p>
        <div class="box-body">
			<div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
				<div class="row">
					<div class="col-sm-12">
						<table class="table table-hover dataTable" id="example1" role="grid" aria-describedby="example1_info">
							<thead>
								<tr role="row">
									<th tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 50px;"> # </th>
									<th tabindex="1" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Client</th>
									<th tabindex="2" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">User</th>
									<th tabindex="3" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Date</th>
									<th tabindex="4" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Status</th>
									<th tabindex="5" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Discount</th>
									<th tabindex="6" aria-controls="example1" rowspan="1" colspan="1" style="width: 111px;">Updated At</th>
									<th style="width: 150px"></th>
								</tr>
							</thead>
							<tbody>
							<?php if(!$quotes->count()): ?>
								<tr>
									<td colspan="8" class="text-center">
										No qoutes found
									</td>
								</tr>
							<?php else: ?>
					            <?php $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					                <tr>
					                    <?php echo Form::open(array('class' => 'form-inline', 'method' => 'DELETE', 'route' => array('quotes.destroy'))); ?>

											<td>#</td>
					                        <td><a href="<?php echo e(route('quotes.show', $quote->id)); ?>"><?php echo e($quote->client_id); ?></a></td>
					                        <td><?php echo e($quote->user_id); ?></td>
					                        <td><?php echo e($quote->created_at); ?></td>
					                        <td><?php echo e($quote->status_id); ?></td>
					                        <td><?php echo e($quote->discount_id); ?></td>
					                        <td><?php echo e($quote->updated_at); ?></td>
					                        <td style="text-align: center">
					                            <?php echo link_to_route('quotes.edit', 'Edit', $quote->id, array('class' => 'btn btn-info btn-sm btn-flat glyphicon glyphicon-edit')); ?>,
					                            <?php echo Form::submit('Delete', array('class' => 'btn btn-danger btn-sm btn-flat glyphicon glyphicon-trash')); ?>

					                        </td>
					                    <?php echo Form::close(); ?>

					                </tr>
					            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					            <?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
<div class="pull-right">
	<?php echo $quotes->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>