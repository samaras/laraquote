 
<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('pageheader'); ?>
    	Edit Category
	<?php $__env->stopSection(); ?>

 
    <?php echo Form::model($category, ['method' => 'PATCH', 'route' => ['categories.update', $category]], array('class'=>'form-horizontal')); ?>

        <?php echo $__env->make('categories/partials/_form', ['submit_text' => 'Edit Category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>