<?php $__env->startSection('pagedescription'); ?>
	System Users and Salespeople
<?php $__env->stopSection(); ?> 
 
<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
	<div class="box box-primary">
		<div class="box-header with-border">
			<div class="col-md-6" style="padding-top: 5px"><?php echo link_to_route('groups.create', 'Create User', array(), ['class' => 'btn btn-default']); ?></div>
			<div class="col-md-6"><?php echo $__env->make('toolboxsearch', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
		</div>
 
		<p>&nbsp;</p>
        <div class="box-body">
                <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                    <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-hover dataTable" id="example1" role="grid" aria-describedby="example1_info">
                                <thead>
                                    <tr role="row">
										<td style="width: 50px">#</td>
                                        <th rowspan="1" colspan="1" style="width: 111px;">First Name</td>
					                    <th rowspan="1" colspan="1" style="width: 111px;">Last Name</td>
					                    <th rowspan="1" colspan="1" style="width: 111px;">Email</td>
					                    <th rowspan="1" colspan="1" style="width: 111px;">Last Login</td>
					                    <th rowspan="1" colspan="1" style="width: 111px;">Active</td>
					                    <th rowspan="1" colspan="1" style="width: 111px;">Group(s)</td>
                                        <th rowspan="1" colspan="1" style="width: 111px;">Created At</th>
                                        <th style="width: 150px"></th>
                                    </tr>
                                </thead>
                                <tbody>
								<?php if( !$users->count() ): ?>
									<tr>
										<td colspan="9" class="text-center">No users found</td>
									</tr>
								<?php else: ?>
									<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					                <tr>
					                    <?php echo Form::open(array('class' => 'form-inline', 'method' => 'DELETE', 'route' => array('users.destroy', $user->id))); ?>

                                            <td></td>
					                        <td><a href="<?php echo e(route('users.show', $user->id)); ?>"><?php echo e($user->first_name); ?></a></td>
					                        <td><a href="<?php echo e(route('users.show', $user->id)); ?>"><?php echo e($user->last_name); ?></a></td>
					                        <td><?php echo e($user->email); ?></td>
					                        <td><?php echo e($user->last_login); ?></td>
					                        <td>
					                        	<?php if($user->active==1): ?>
					                        		Active
				                        		<?php else: ?>
				                        			InActive
			                        			<?php endif; ?>

					                        </td>
					                        <td>Sales</td>
					                        <td></td>
					                        <td style="text-align: center">
					                            <?php echo link_to_route('users.edit', 'Edit', $user->id, array('class' => 'btn btn-info')); ?>,
					                            <?php echo Form::submit('Delete', array('class' => 'btn btn-danger')); ?>

					                        </td>
					                    <?php echo Form::close(); ?>

					                </tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
								<?php endif; ?>
		           				</tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
		<div class="pull-right">
			<?php echo $users->render(); ?>

		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>