 
<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('pageheader'); ?>
    	Create Client
    <?php $__env->stopSection(); ?>
 
    <?php echo Form::model(new App\Models\Client, ['route' => ['clients.store']]); ?>

        <?php echo $__env->make('clients/partials/_form', ['submit_text' => 'Create Client'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>