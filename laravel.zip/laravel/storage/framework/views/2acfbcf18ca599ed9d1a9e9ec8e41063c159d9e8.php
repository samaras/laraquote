 
<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('pageheader'); ?>
    	Edit Client
	<?php $__env->stopSection(); ?>
 
    <?php echo Form::model($client, ['method' => 'PATCH', 'route' => ['clients.update', $client]]); ?>

        <?php echo $__env->make('clients/partials/_form', ['submit_text' => 'Edit Client'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>