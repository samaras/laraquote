<?php

namespace App\Http\Requests;

class UserRequest extends Request
{
	
}