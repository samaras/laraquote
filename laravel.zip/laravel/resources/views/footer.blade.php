
<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
          <b>Version</b> 2.0
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="http://obrerosoft.com" target="_blank">Obrerosoft (Pty) Ltd</a>.</strong> All rights reserved.
</footer>
