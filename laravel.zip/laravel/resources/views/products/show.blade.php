@extends('app')
 
@section('content')
    This is my /resources/views/products/index.blade.php file!
@endsection