<h1>
	{!! $page_title !!}
	<small>@yield('pagedescription')Control Panel</small>
</h1>
