@extends('app')
 
@section('content')
    This is my /resources/views/projects/index.blade.php file!
@endsection